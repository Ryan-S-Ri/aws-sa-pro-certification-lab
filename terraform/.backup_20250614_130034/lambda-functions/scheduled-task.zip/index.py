import json
import boto3
import os
from datetime import datetime

# Initialize AWS services
cloudwatch = boto3.client('cloudwatch')
environment = os.environ.get('ENVIRONMENT', 'dev')

def handler(event, context):
    """
    Scheduled task that runs periodically
    """
    print(f"Scheduled task running at: {datetime.now().isoformat()}")
    print(f"Event: {json.dumps(event)}")
    
    try:
        # Perform scheduled tasks
        perform_health_check()
        cleanup_old_data()
        send_metrics()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Scheduled task completed successfully',
                'timestamp': datetime.now().isoformat()
            })
        }
        
    except Exception as e:
        print(f"Error in scheduled task: {str(e)}")
        # Send metric for failed execution
        cloudwatch.put_metric_data(
            Namespace='ScheduledTasks',
            MetricData=[
                {
                    'MetricName': 'TaskFailures',
                    'Value': 1,
                    'Unit': 'Count',
                    'Dimensions': [
                        {
                            'Name': 'Environment',
                            'Value': environment
                        }
                    ]
                }
            ]
        )
        raise e

def perform_health_check():
    """Perform system health checks"""
    print("Performing health checks...")
    
    # Example: Check various services
    # Add your health check logic here
    
    # Send success metric
    cloudwatch.put_metric_data(
        Namespace='ScheduledTasks',
        MetricData=[
            {
                'MetricName': 'HealthCheckSuccess',
                'Value': 1,
                'Unit': 'Count',
                'Dimensions': [
                    {
                        'Name': 'Environment',
                        'Value': environment
                    }
                ]
            }
        ]
    )
    
    print("Health checks completed")

def cleanup_old_data():
    """Clean up old data from various sources"""
    print("Cleaning up old data...")
    
    # Example: Delete old logs, temporary files, etc.
    # Add your cleanup logic here
    
    print("Cleanup completed")

def send_metrics():
    """Send custom metrics to CloudWatch"""
    print("Sending metrics...")
    
    # Example custom metrics
    cloudwatch.put_metric_data(
        Namespace='ScheduledTasks',
        MetricData=[
            {
                'MetricName': 'TaskExecutions',
                'Value': 1,
                'Unit': 'Count',
                'Dimensions': [
                    {
                        'Name': 'Environment',
                        'Value': environment
                    },
                    {
                        'Name': 'TaskType',
                        'Value': 'Scheduled'
                    }
                ]
            }
        ]
    )
    
    print("Metrics sent")

import json
import boto3
import os
from datetime import datetime

# Initialize AWS services
dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('TABLE_NAME', 'dummy-table')

def handler(event, context):
    """
    Main Lambda handler for API requests
    """
    print(f"Received event: {json.dumps(event)}")
    
    try:
        # Parse the HTTP method
        http_method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        
        if http_method == 'GET' and path == '/items':
            return get_items()
        elif http_method == 'POST' and path == '/items':
            body = json.loads(event.get('body', '{}'))
            return create_item(body)
        elif http_method == 'GET' and path.startswith('/items/'):
            item_id = path.split('/')[-1]
            return get_item(item_id)
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Not Found'})
            }
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def get_items():
    """Get all items from DynamoDB"""
    try:
        table = dynamodb.Table(table_name)
        response = table.scan()
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'items': response.get('Items', []),
                'count': response.get('Count', 0)
            })
        }
    except Exception as e:
        print(f"Error getting items: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get items'})
        }

def create_item(item_data):
    """Create a new item in DynamoDB"""
    try:
        table = dynamodb.Table(table_name)
        
        # Add metadata
        item_data['id'] = item_data.get('id', str(datetime.now().timestamp()))
        item_data['created_at'] = datetime.now().isoformat()
        
        table.put_item(Item=item_data)
        
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(item_data)
        }
    except Exception as e:
        print(f"Error creating item: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to create item'})
        }

def get_item(item_id):
    """Get a specific item from DynamoDB"""
    try:
        table = dynamodb.Table(table_name)
        response = table.get_item(Key={'id': item_id})
        
        if 'Item' in response:
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps(response['Item'])
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Item not found'})
            }
    except Exception as e:
        print(f"Error getting item: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get item'})
        }

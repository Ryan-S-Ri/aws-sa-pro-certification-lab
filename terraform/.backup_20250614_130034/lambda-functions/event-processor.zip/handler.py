print('Hello from Lambda')

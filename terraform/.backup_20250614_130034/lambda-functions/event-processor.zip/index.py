import json
import boto3
import os
from datetime import datetime

# Initialize AWS services
sqs = boto3.client('sqs')
sns = boto3.client('sns')

queue_url = os.environ.get('QUEUE_URL', '')
sns_topic = os.environ.get('SNS_TOPIC', '')

def handler(event, context):
    """
    Process events from various sources (SQS, DynamoDB Streams, etc.)
    """
    print(f"Processing event: {json.dumps(event)}")
    
    try:
        # Determine event source
        if 'Records' in event:
            for record in event['Records']:
                if 'eventSource' in record:
                    if record['eventSource'] == 'aws:sqs':
                        process_sqs_record(record)
                    elif record['eventSource'] == 'aws:dynamodb':
                        process_dynamodb_record(record)
                    else:
                        print(f"Unknown event source: {record['eventSource']}")
        else:
            # Direct invocation
            process_direct_event(event)
            
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Events processed successfully'})
        }
        
    except Exception as e:
        print(f"Error processing events: {str(e)}")
        # Send notification about failure
        if sns_topic:
            sns.publish(
                TopicArn=sns_topic,
                Subject='Event Processing Failed',
                Message=f'Error: {str(e)}\nEvent: {json.dumps(event)}'
            )
        raise e

def process_sqs_record(record):
    """Process a single SQS record"""
    try:
        body = json.loads(record['body'])
        print(f"Processing SQS message: {body}")
        
        # Add your business logic here
        # Example: Process order, update inventory, etc.
        
        # Simulate processing
        process_data(body)
        
    except Exception as e:
        print(f"Error processing SQS record: {str(e)}")
        raise e

def process_dynamodb_record(record):
    """Process a DynamoDB stream record"""
    try:
        print(f"Processing DynamoDB record: {record['eventName']}")
        
        if record['eventName'] == 'INSERT':
            new_image = record['dynamodb'].get('NewImage', {})
            print(f"New item inserted: {new_image}")
            
            # Example: Send notification for new items
            if sns_topic:
                sns.publish(
                    TopicArn=sns_topic,
                    Subject='New Item Created',
                    Message=f'A new item was created: {json.dumps(new_image)}'
                )
                
        elif record['eventName'] == 'MODIFY':
            old_image = record['dynamodb'].get('OldImage', {})
            new_image = record['dynamodb'].get('NewImage', {})
            print(f"Item modified - Old: {old_image}, New: {new_image}")
            
        elif record['eventName'] == 'REMOVE':
            old_image = record['dynamodb'].get('OldImage', {})
            print(f"Item removed: {old_image}")
            
    except Exception as e:
        print(f"Error processing DynamoDB record: {str(e)}")
        raise e

def process_direct_event(event):
    """Process direct Lambda invocation"""
    print(f"Processing direct invocation: {event}")
    
    # Add your business logic here
    process_data(event)

def process_data(data):
    """Common data processing logic"""
    # Simulate some processing
    print(f"Processing data: {data}")
    
    # Example: Validate data, transform, store, etc.
    if 'action' in data:
        if data['action'] == 'notify':
            if sns_topic:
                sns.publish(
                    TopicArn=sns_topic,
                    Subject='Event Notification',
                    Message=json.dumps(data)
                )
        elif data['action'] == 'queue':
            if queue_url:
                sqs.send_message(
                    QueueUrl=queue_url,
                    MessageBody=json.dumps(data)
                )
    
    print("Data processed successfully")
